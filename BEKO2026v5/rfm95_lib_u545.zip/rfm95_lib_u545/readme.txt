Biblioteka RFM95 dla MCU z serii STM32U545
==========================================

Wersja: 21.10.2024
Przemysław Korpas

Biblitoeka opracowana na bazie aplikacji „ping-pong” na SK-iM880A 
https://github.com/Lora-net/LoRaMac-node

Biblioteka udostępniana na zasadach "as-is".

==========================================


Zmiany w stosunku do wersji udostępnionej dla STM32L476 (piszę z pamięci, może coś pominąłem; numery linii wg plików w wersji U545):
1. sx1276.c:1309-1311
   Pomiędzy transmisjami SPI dodano oczekiwanie na wykonanie transmisji przez hardware.
2. board.h:23-24
   #include zmienione na właściwe dla serii U545.
3. board.h:66-81
   Definicje wyprowadzeń dostosowane do shieldu i płytki NUCLEO-U545
4. gpio-board.c:152-205
   Rozpisano niezależnie wszystkie 16 przypadków przerwań zewnętrznych EXTI - wcześniej przerwania powyżej EXTI5 były grupowane z niewiadomego powodu, co skutkowało tym, że nie odpalały się ich procedury obsługi
   W konsekwencji w liniach 305-392 trzeba było dopisać procedury ISR tak aby był komplet dla każdego z 16 EXTI.
5. gpio-board.c:426
   W rodzinie U545 zmieniła się nazwa callbacku wołanego przez HAL - kiedyś był 1 wspólny, teraz jest osobny callback dla przerwań skonfigurowanych na wyzwolenie zboczem narastającym i opadającym. Tutaj zdefiniowano tylko działanie dla "rising", bo "falling" biblioteka nie wykorzystuje.
6. rtc-board.c:205-206
   Zmienione dzielniki sygnału zegarowego dla RTC w taki sposób, aby sekunda w RTC mniej więcej odpowiadała sekundzie rzeczywistej.
   UWAGA: wstawione wartości są dobrane eksperymentalnie a nie wyliczone... tak po prawdzie, to one są dziwne i wskazują, że coś jest jeszcze źle skonfigurowane w okolicach RTC. TO WYMAGA WYJAŚNIENIA.
7. rtc-board:229-230
   Zmianie uległa nazwa przerwania.
8. rtc-board:326-370
   (tu występują różnice, ale nie stwierdzę teraz, czy są one konieczne - do wyjaśnienia)
9. rtc-board:720-731
   Zmiana nazwy funkcji IRQ handlera.
   (inne zmiany: nie stwierdzę teraz, czy są one konieczne - do wyjaśnienia)
10. spi-board.c:50-147
   Konfigurację peryferium SPI uzupełniono o nowe pola dostępne w rozdzinie U545 aby upewnić się, że peryferium nie jest przypadkiem konfigurowane w jakiś dziwny tryb wynikający z braku poprawnego zainicjowania wartości w bardziej rozbudowanych strukturach konfiguracyjnych.
   - funkcje SpiInit() oraz SpiFormat()
   W funkcji SpiFrequency() kryje się wredna różnica wynikająca z zupełnie innej definicji bitów w rejestrze, w którym konfiguruje się m.in. prędkość transmisji. Docelowo tak funkcja nie jest używana na rzecz ustawienia odpowiedniego baudrate-prescalera w funkcji SpiFormat().
11. timer.c:206-207
   Dodano warunek, którzy przeciwdziała wpadaniu w HardFault - biblioteka wcześniej zeruje głowę listy TimerListHead, co jest irracjonalne. Dodany warunek zabezpieczenia przed HardFault, ale nie wyjaśnia, dlaczego biblioteka zachowuje się w ten sposób. Nie wiadomo też, czy ta łata nie ma jakichś skutków ubocznych.

   